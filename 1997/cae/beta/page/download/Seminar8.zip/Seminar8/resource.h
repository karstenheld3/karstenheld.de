//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by seminar.rc
//
#define IDR_MAIN_FRAME                  101
#define IDR_DOCUMENT                    102
#define IDD_CREATE                      103
#define IDC_X                           1001
#define IDC_Y                           1002
#define ID_CREATE                       40002
#define ID_EDIT                         40005
#define ID_FILE                         40006
#define ID_EDIT_ALPHA                   40007
#define IDM_CREATE                      40008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40009
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
