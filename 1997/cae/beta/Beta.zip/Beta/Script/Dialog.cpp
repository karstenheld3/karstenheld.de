
class TestDialog : public CDialog
{
  public:
  TestDialog() : CDialog(TestDialog::IDD) {}

  enum { IID = IDD_TEST_DIALOG };
};

void AufrufTestDialog()
{
  TestDialog Dialog;
  Dialog.DoModal();
}