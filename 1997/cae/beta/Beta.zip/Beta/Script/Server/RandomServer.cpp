
#include <stdlib.h>
#include <objbase.h>
#include "IRandom.h"

/////////////////////////////////////////////////////////////////////////////
// global unique identifiers

GUID CLSID_Random =
  {0xC0002270,0x54E5,0x11D1,{0xBC,0x97,0x00,0x80,0x5F,0x8C,0x5D,0x94}};

GUID IID_IRandom =
  {0xC0002271,0x54E5,0x11D1,{0xBC,0x97,0x00,0x80,0x5F,0x8C,0x5D,0x94}};

/////////////////////////////////////////////////////////////////////////////
// global reference counter

ULONG _GlobalReferenceCounter = 0;

/////////////////////////////////////////////////////////////////////////////
// class Random

class Random : public IRandom
{
  private:
  ULONG _LocalReferenceCounter;

  public:
  HRESULT __stdcall QueryInterface(REFIID riid,void ** ppv)
  {
    * ppv = NULL;

    if ((riid == IID_IRandom) || (riid == IID_IUnknown))
    {
      * ppv = (IRandom *) this;
      AddRef();
      return S_OK;
    }

    return E_NOINTERFACE;
  }

  ULONG __stdcall AddRef()
  {
    _GlobalReferenceCounter++;
    return (++_LocalReferenceCounter);
  }

  ULONG __stdcall Release()
  {
    _GlobalReferenceCounter--;
    if ((--_LocalReferenceCounter) == 0)
    {
      delete this;
      return 0;
    }
    return _LocalReferenceCounter;
  }

  double __stdcall GetValue()
  {
    return ((1.0 * rand()) / RAND_MAX);
  }

  Random()
  {
    _LocalReferenceCounter = 0;
  }
};

/////////////////////////////////////////////////////////////////////////////
// class RandomClassFactory

class RandomClassFactory : public IClassFactory
{
  private:
  ULONG _LocalReferenceCounter;

  public:
  HRESULT __stdcall QueryInterface(REFIID riid,void ** ppv)
  {
    * ppv = NULL;

    if ((riid == IID_IClassFactory) || (riid == IID_IUnknown))
    {
      * ppv = (IClassFactory *) this;
      AddRef();
      return S_OK;
    }

    return E_NOINTERFACE;
  }

  ULONG __stdcall AddRef()
  {
    _GlobalReferenceCounter++;
    return (++_LocalReferenceCounter);
  }

  ULONG __stdcall Release()
  {
    _GlobalReferenceCounter--;
    return (--_LocalReferenceCounter);
  }

  HRESULT __stdcall CreateInstance
    (IUnknown * UnkOuter,REFIID riid,void ** ppv)
  {
    * ppv = NULL;

    if (UnkOuter != NULL)
      return CLASS_E_NOAGGREGATION;

    * ppv = new Random;

    if (* ppv == NULL)
      return E_OUTOFMEMORY;

    HRESULT Result = ((Random *) * ppv)->QueryInterface(riid,ppv);

    if (FAILED(Result))
      delete ppv;

    return Result;
  }

  HRESULT __stdcall LockServer(BOOL Lock)
  {
    if (Lock == TRUE)
      AddRef();
    else
      Release();

    return S_OK;
  }
  
  RandomClassFactory()
  {
    _LocalReferenceCounter = 0;
  }
};

/////////////////////////////////////////////////////////////////////////////
// special entry points required for inproc servers

RandomClassFactory _RandomClassFactory;

STDAPI DllGetClassObject(REFCLSID rclsid,REFIID riid,void ** ppv)
{
  * ppv = NULL;

  if (rclsid != CLSID_Random)
    return CLASS_E_CLASSNOTAVAILABLE;

  return (_RandomClassFactory.QueryInterface(riid,ppv));
}

STDAPI DllCanUnloadNow()
{
  if (_GlobalReferenceCounter == 0)
    return S_OK;
  else
    return S_FALSE;
}
