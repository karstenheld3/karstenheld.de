
#include <iostream.h>
#include <conio.h>
#include <objbase.h>
#include "IRandom.h"

/////////////////////////////////////////////////////////////////////////////
// global unique identifiers

GUID CLSID_Random =
  {0xC0002270,0x54E5,0x11D1,{0xBC,0x97,0x00,0x80,0x5F,0x8C,0x5D,0x94}};

GUID IID_IRandom =
  {0xC0002271,0x54E5,0x11D1,{0xBC,0x97,0x00,0x80,0x5F,0x8C,0x5D,0x94}};

/////////////////////////////////////////////////////////////////////////////
// C++ main entry point

void main()
{
  IClassFactory * ClassFactory;
  IRandom * Random;

  if (CoInitialize(NULL) >= 0)
  {
    if (CoGetClassObject(CLSID_Random,CLSCTX_SERVER,NULL,
                         IID_IClassFactory,(void **) & ClassFactory) >= 0)
    {
      if (ClassFactory->CreateInstance(NULL,IID_IRandom,
                                       (void **) & Random) >= 0)
      {
        for (int i = 0; i <= 8; i++)
          cout << "Value " << i << " = " << Random->GetValue() << endl;

        Random->Release();
      }
      ClassFactory->Release();
    }
    CoFreeUnusedLibraries();
    CoUninitialize();
  }
}
