
#ifndef __IRandom__
#define __IRandom__

/////////////////////////////////////////////////////////////////////////////
// interface IRandom

interface IRandom : public IUnknown
{
  virtual double __stdcall GetValue() = 0;
};

#endif
