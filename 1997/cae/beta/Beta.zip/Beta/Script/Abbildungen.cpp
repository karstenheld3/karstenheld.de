-----------------------------------------------------------------------------
  A B B I L D U N G   8   N E U
-----------------------------------------------------------------------------
// CLSID fuer die Klasse Random
GUID CLSID_Random =
  {0xC0002270,0x54E5,0x11D1,{0xBC,0x97,0x00,0x80,0x5F,0x8C,0x5D,0x94}};

// beim Start der DLL automatisch erzeugte Instanz der Klasse RandomClassFactory
RandomClassFactory _RandomClassFactory;

STDAPI DllGetClassObject(REFCLSID rclsid,REFIID riid,void ** ppv)
{
  * ppv = NULL;

  if (rclsid != CLSID_Random)
    return CLASS_E_CLASSNOTAVAILABLE;
}
-----------------------------------------------------------------------------
  A B B I L D U N G   9   N E U
-----------------------------------------------------------------------------
// CLSID fuer die Klasse Random
GUID CLSID_Random =
  {0xC0002270,0x54E5,0x11D1,{0xBC,0x97,0x00,0x80,0x5F,0x8C,0x5D,0x94}};

void main()
{
void main()
{
  IClassFactory * ClassFactory;
  IRandom * Random;

  CoInitialize(NULL);
  CoGetClassObject(CLSID_Random,CLSCTX_SERVER,NULL,
                   IID_IClassFactory,(void **) & ClassFactory);
  ClassFactory->CreateInstance(NULL,IID_IRandom,(void **) & Random);

  // Jetzt zeigt Random auf die Implementierung des Interfaces IRandom
  // in einer Instanz der Klasse Random im Server. Die Funktionen des
  // Interfaces koennten nun aufgerufen werden.

  Random->Release();
  ClassFactory->Release();
  CoFreeUnusedLibraries();
  CoUninitialize();
}
-----------------------------------------------------------------------------