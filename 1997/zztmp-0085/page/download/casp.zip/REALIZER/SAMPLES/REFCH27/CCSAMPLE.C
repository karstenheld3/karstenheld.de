/************************************************
 *
 *  Realizer Reference Manual Sample Program
 *
 *  Chapter 27: CCSample.C
 *
 *  Copyright � 1991 Within Technologies, Inc.
 *  All rights reserved
 ************************************************/


#include <windows.h> 
#include "CustCtrl.h" 
 
HANDLE	hLibInstance; 
 
/* 
 * Constants for the countdown timer 
 */ 
 
#define TIMER_CLASS	"CountDownTimer" 
 
#define TIMER_FONT	0		/* 2 bytes, handle to font */ 
#define TIMER_DOWNCT	2	/* 2 bytes, current count (65535 max) */ 
#define TIMER_ON		4	/* 2 bytes, non-zero if on */ 
							/*  bit 0: set if timer is running */ 
							/*  bit 1: toggles display at 0 */ 
#define TIMER_ENDTICK	6	/* 4 bytes, GetTickCount value at which */ 
							/*   TIMER_DOWNCT should hit zero */ 
#define TIMER_EXTRA	10 
 
 
/* 
 * Constants for the size message generator 
 */ 
 
#define SIZEMSG_CLASS	"SizeMsg" 
#define SIZEMSG_EXTRA	0 
 
 
/* 
 * Notify Parent - notifies the custom control's form 
 */ 
 
void NotifyParent (HWND hWnd) 
{ 
    SendMessage( 
        GetParent(hWnd),			/* this is the form */ 
        WM_COMMAND, 
        GetWindowWord(hWnd, GWW_ID),	/* this is hWnd's item num */ 
        MAKELONG((int)hWnd, BN_CLICKED)	/* looks like a click */ 
    ); 
} 
 
 
/* 
 * FormatSecs - formats the display for the timer 
 */ 
 
void FormatSecs(HWND hWnd, LPSTR buf) 
{ 
	WORD	wOn, wSecs; 
	int		len; 
 
	wOn = GetWindowWord(hWnd, TIMER_ON); 
	wSecs = GetWindowWord(hWnd, TIMER_DOWNCT); 
 
	if (wSecs > 9999) 
		wsprintf(buf, "****"); 
	else { 
		len = wsprintf(buf, "%d", wSecs); 
		if ((wOn & 2) != 0) 
			buf[len - 1] = '_'; 
	} 
} 
 
 
/* 
 * TimerServer - Window procedure for the countdown timer 
 */ 
 
extern LONG FAR PASCAL 
TimerServer(HWND hWnd, unsigned msg, WORD wP, LONG lP) 
{ 
	PAINTSTRUCT	ps; 
	RECT		cr; 
	HFONT		hFont; 
	HDC		hDC; 
	HBRUSH	hBgndBrush; 
	LPLONG	lpMods; 
	LONG		lTick, lNewCount; 
	WORD		wOn; 
	int		height, wCount; 
	char		buf[10]; 
 
	switch (msg) { 
 
	case WM_DESTROY: 
 
		/* If the timer is running, kill it */ 
		if (GetWindowWord(hWnd, TIMER_ON)) 
			KillTimer(hWnd, 1); 
		break; 
 
	case WM_TIMER: 
 
		/* If the timer is still running... */ 
		if (wOn = GetWindowWord(hWnd, TIMER_ON)) { 
 
			/* Force the display to be updated */ 
			InvalidateRect(hWnd, NULL, TRUE); 
 
			if (wCount = GetWindowWord(hWnd, TIMER_DOWNCT)) { 
 
				/* Adjust the count to the actual time */ 
				lTick = GetWindowLong(hWnd, TIMER_ENDTICK); 
				lTick = (lTick - GetTickCount() + 500) / 1000; 
				if (HIWORD(lTick)) 
					wCount = 0; 
				else 
					wCount = LOWORD(lTick); 
				SetWindowWord(hWnd, TIMER_DOWNCT, wCount); 
 
			} else { 
 
				/* The timer is at zero. Toggle the display */ 
				SetWindowWord(hWnd, TIMER_ON, wOn ^ 2); 
 
			} 
 
			/* If the timer has hit zero, notify the form */ 
			if (wCount == 0) 
				NotifyParent(hWnd); 
		} 
		break; 
 
	case WM_SETFONT: 
 
		/* Store the font handle in TIMER_FONT */ 
		if (wP) { 
			SetWindowWord(hWnd, TIMER_FONT, wP); 
			InvalidateRect(hWnd, NULL, TRUE); 
		} 
		break; 
 
	case CCM_SETNUM: 
 
		/* Get the modifer list */ 
		lpMods = (LPLONG)lP; 
 
		/* If the new count is out of range, return 0 */ 
		lNewCount = lpMods[0]; 
		if (lNewCount < 0 || lNewCount > 65535) 
			return (0); 
 
		/* Store the new count and force a display update */ 
		SetWindowWord(hWnd, TIMER_DOWNCT, LOWORD(lNewCount)); 
		InvalidateRect(hWnd, NULL, TRUE); 
 
		/* Resynchronize the timer */ 
		KillTimer(hWnd, 1);					 
		if (lNewCount == 0) 
			SetWindowWord(hWnd, TIMER_ON, 0); 
		else { 
			SetWindowWord(hWnd, TIMER_ON, 1); 
			SetTimer(hWnd, 1, 1000, NULL); 
			SetWindowLong(hWnd, TIMER_ENDTICK,  
					lNewCount * 1000 + GetTickCount()); 
		} 
		return (1);			 
 
	case CCM_GETNUM: 
 
		/* Return the value of the timer, -1 if it's off */ 
		if (GetWindowWord(hWnd, TIMER_ON)) 
			return (GetWindowWord(hWnd, TIMER_DOWNCT)); 
		else 
			return (-1L); 
 
	case CCM_QDEFAULTSIZE: 
 
		/* Calculate the size of "9999" and return that size */ 
		hDC = GetDC(hWnd); 
		if (hFont = GetWindowWord(hWnd, TIMER_FONT)) 
			SelectObject(hDC, hFont); 
		cr.left = cr.top = 0; 
		cr.right = cr.bottom = 100; 
		height = DrawText(hDC, "9999", -1, &cr,  
							DT_SINGLELINE | DT_CALCRECT); 
		ReleaseDC(hWnd, hDC); 
		return (MAKELONG(cr.right - cr.left + 2, height + 2)); 
 
	case CCM_GETFLAGS: 
	case CCM_FORMSIZED: 
	case CCM_RESETCONTENT: 
		break; 
 
	case WM_ERASEBKGND: 
 
		/* let WM_PAINT do it */ 
		return (1L); 
 
	case WM_PAINT: 
 
		/* Always do the whole display */ 
		InvalidateRect(hWnd, NULL, TRUE);	 
 
		BeginPaint(hWnd, &ps); 
 
		/* Color the background */ 
		hBgndBrush = (HBRUSH)SendMessage(GetParent(hWnd), 
			WM_CTLCOLOR, ps.hdc, MAKELONG(hWnd, CTLCOLOR_STATIC)); 
		FillRect(ps.hdc, &ps.rcPaint, hBgndBrush); 
 
		/* Display the timer count */ 
		FormatSecs(hWnd, buf); 
		GetClientRect(hWnd, &cr); 
		if (hFont = GetWindowWord(hWnd, TIMER_FONT)) 
			SelectObject(ps.hdc, hFont); 
		SetBkMode(ps.hdc, TRANSPARENT); 
		DrawText(ps.hdc, buf, -1, &cr,  
					DT_SINGLELINE | DT_RIGHT | DT_VCENTER); 
		EndPaint(hWnd, &ps); 
		break; 
 
	default: 
		return (DefWindowProc(hWnd, msg, wP, lP)); 
	} 
 
	return (0L); 
} 
 
 
/* 
 * SizeMsgServer - Window procedure for the 
 *   size message generator 
 */ 
 
 
extern LONG FAR PASCAL 
SizeMsgServer(HWND hWnd, unsigned msg, WORD wP, LONG lP) 
{ 
	switch (msg) { 
 
		case CCM_QDEFAULTSIZE: 
			return(0L); 
 
		case CCM_GETFLAGS: 
			return(0L); 
 
		case CCM_FORMSIZED: 
			NotifyParent(hWnd); 
			break; 
 
		default: 
			return(DefWindowProc(hWnd, msg, wP, lP)); 
		} 
 
	return (0L); 
} 
 
 
/* 
 * LibMain(hInstance, wDataSegment, wHeapSize, lpszCmdLine) 
 * 
 *    hInstance      library instance handle 
 *    wDataSegment   library data segment 
 *    wHeapSize      default heap size 
 *    lpszCmdLine    command line arguments 
 * 
 * LibMain is called by LibEntry, which is called by Windows  
 * when the DLL is loaded.  The LibEntry routine is provided 
 * in the LIBENTRY.OBJ in the SDK Link Libraries disk. The  
 * source, LIBENTRY.ASM, is also provided.   
 * 
 * LibEntry initializes the DLL's heap, if a HEAPSIZE value is 
 * specified in the DLL's DEF file.  LibEntry then calls 
 * LibMain.  The LibMain function below satisfies that call. 
 * 
 * LibMain registers the custom control window classes. 
 * 
 */ 
  
int FAR PASCAL LibMain( 
   HANDLE      hInstance, 
   WORD        wDataSegment, 
   WORD        wHeapSize, 
   LPSTR       lpszCmdLine) 
{ 
	WNDCLASS		wc; 
 
	if (hLibInstance) return (TRUE); 
 
	/* define class attributes */ 
	wc.style =			CS_HREDRAW | CS_VREDRAW | CS_GLOBALCLASS; 
	wc.lpfnWndProc =		TimerServer; 
	wc.cbClsExtra =		0; 
	wc.cbWndExtra =		TIMER_EXTRA; 
	wc.hInstance =		hInstance; 
	wc.hIcon =			NULL; 
	wc.hCursor =		LoadCursor(NULL, IDC_ARROW); 
	wc.hbrBackground =	(HBRUSH)(COLOR_WINDOW + 1); 
	wc.lpszMenuName =		NULL; 
	wc.lpszClassName =	TIMER_CLASS; 
 
	if (!RegisterClass(&wc)) return (FALSE); 
	 
	/* 
	 * all the parameters for the size message class 
	 * are the same, except for these three 
	 */ 
	  
	wc.lpfnWndProc =		SizeMsgServer; 
	wc.cbWndExtra =		SIZEMSG_EXTRA; 
	wc.lpszClassName = 	SIZEMSG_CLASS;	 
	 
	if (!RegisterClass(&wc)) return (FALSE); 
		 
	hLibInstance = hInstance; 
	return (TRUE); 
} 
 
 
/* 
 * WEP 
 * 
 * Performs cleanup tasks when the DLL is unloaded.  WEP is 
 * called automatically by Windows when the DLL is unloaded. 
 */ 
 
VOID FAR PASCAL WEP(int bSystemExit) 
{ 
	return; 
} 
 
 