/*************************************************************
 *	Realizer Reference Manual Sample Program
 *
 *	Chapter 26:  MyDLL.c
 *
 *	Copyright � 1991 Within Technologies, Inc.
 *	All rights reserved
 *************************************************************/
 
typedef unsigned int	WORD; 
typedef char far		*LPSTR; 
typedef WORD			HANDLE; 
typedef HANDLE			HWND; 
 
/* 
 *  Uppercase - converts all letters in a string to uppercase. 
 */ 
 
void far pascal Uppercase(LPSTR s) 
{ 
	while (*s) { 
		if ((*s >= 'a') && (*s <= 'z')) 
			*s -= 32; 
		s++; 
	} 
} 
 
/* 
 * FindMatch - finds the first occurrence of x within a real array. 
 * 
 * Returns the index of the matching element, or 0 if it isn't found. 
 * The index is based on the Realizer style, with 1 as the 
 * first element. 
 */ 
 
WORD far pascal FindMatch(double far *array, WORD len, double x) 
{ 
	int i; 
 
	for (i = 0; i < len; i++) 
		if (array[i] == x) 
			return(i + 1); 
	return(0); 
} 
 
 
/* 
 * LibMain - DLL initialization routine 
 * 
 * The LibMain function is required for each DLL.  It is called when 
 * the DLL is first loaded.  Any initialization for the library should  
 * be done here.  LibMain should return a value of 1 if the 
 * initialization is successful.           
 */ 
 
int far pascal LibMain(hModule, wDataSeg, cbHeapSize, lpszCmdLine) 
 
WORD    wDataSeg; 
WORD    cbHeapSize; 
LPSTR   lpszCmdLine; 
{ 
    return 1; 
} 
 
 
/* 
 * WEP - DLL cleanup routine 
 * 
 * The WEP function should also be found in each DLL.  It is called when 
 * the DLL is unloaded.  There is no return value. 
 */ 
 
void far pascal WEP(bSystemExit) 
int  bSystemExit; 
{ 
	return; 
} 
 
