/*
 *  Custom Control Library #1
 *
 *  Copyright � 1991-1992 Computer Associates International, Inc.
 *  All rights reserved.
 */
 
#include <windows.h>
#include "CustCtrl.h"

/*	Globals for all copies of this DLL */
HANDLE	hLibInstance;
FARPROC	origSBSrv;
FARPROC sbFiltSrv;

/*  Window Class Names */
#define	CLOCK_CLASS		"CC_Clock"
#define TIMER_CLASS		"CC_Timer"
#define SBAR_CLASS		"CC_ScrollBar"
#define	SIZEMSG_CLASS	"CC_SizeMsg"
#define	LINES_CLASS		"CC_Lines"

/* Clock definitions */
#define CLOCK_FONT	0
#define	CLOCK_EXTRA	2

/* Timer definitions */
#define TIMER_FONT		0		/* 2 bytes, handle to font */
#define TIMER_DOWNCT	2		/* 2 bytes, current down counter (65535 max) */
#define TIMER_ON		4		/* 2 bytes, non-zero if on */
								/* bit 1 always set when on */
								/* bit 2 toggled internally to vary display */
#define TIMER_FORMAT	6		/* 2 bytes, format for display: */
								/* 0 (default): seconds only, up to 9999 */
								/* 1: mins:secs, up to 99:59 */
								/* 2: hrs:mins:secs, up to 18:12:15 */
#define TIMER_ENDTIC	8		/* 4 bytes, GetTickCount value at which */
								/* TIMER_DOWNCT should hit zero */
#define TIMER_EXTRA		12

/* ScrollBar definitions */
#define SBAR_SBAR	0		/* 2 bytes, HWND of the SCROLLBAR child */
#define SBAR_FLAGS	2		/* 2 bytes, flag bits */
	#define SBF_VERT	1		/* make a vertical scroll bar */
	#define SBF_ALIGN1	2		/* align to full bottom or right */
	#define SBF_ALIGN2	4		/* align to full minus the other scroll bar */

#define SBAR_MIN	4		/* 2 bytes, minimum */
#define SBAR_MAX	6		/* 2 bytes, maximum */
#define SBAR_VAL	8		/* 2 bytes, current value */
#define SBAR_PAGESZ	10		/* 2 bytes, page size */
#define SBAR_HADCAP	12		/* 2 bytes, BOOL TRUE if hSBar had the capture */
#define SBAR_NTFVAL	14		/* SBAR_VAL at last SETNUM or notification */
#define SBAR_EXTRA	16

/* Size Message definitions */
#define SIZEMSG_CLASS	"CC_SizeMsg"
#define SIZEMSG_EXTRA	0

/* Lines definitions */
#define LINES_CLASS		"CC_Lines"
#define LINES_CX		0
#define LINES_CY		2
#define	LINES_FILLFORM	4
#define LINES_EXTRA		6

LONG FAR PASCAL ClockSrv(HWND, unsigned, WORD, LONG);
LONG FAR PASCAL TimerSrv(HWND, unsigned, WORD, LONG);
LONG FAR PASCAL SSFilter(HWND, unsigned, WORD, LONG);
LONG FAR PASCAL ScrollSrv(HWND, unsigned, WORD, LONG);
LONG FAR PASCAL SizeMsgSrv(HWND, unsigned, WORD, LONG);
LONG FAR PASCAL LinesSrv(HWND, unsigned, WORD, LONG);

/*
 * Custom Control General Purpose Functions
 */

void NotifyParent(HWND hWnd)
{
	SendMessage(
		GetParent(hWnd),					/* this is the form */
		WM_COMMAND,
		GetWindowWord(hWnd, GWW_ID),		/* this is the item num */
		MAKELONG((int)hWnd, BN_CLICKED)		/* looks like a click */
	);
}


/*********************************
 *  Digital Clock Custom Control 
 *********************************/

typedef struct
{
	int hr;
	int min;
	int sec;
} TIME;

extern void GetTime(TIME FAR *); 	/* ASM function */

LONG FAR PASCAL ClockSrv(hWnd, msg, wP, lP)
HWND		hWnd;
unsigned	msg;
WORD		wP;
LONG		lP;
{
	TIME		time;
	char		buf[10];
	RECT		cr;
	HFONT		hFont;
	int			height;
	HDC			hDC;
	PAINTSTRUCT	ps;
	HBRUSH		hBackBr;

	switch (msg) {

	case WM_CREATE:
		SetTimer(hWnd, 1, 1000, NULL);
		break;

	case WM_DESTROY:
		KillTimer(hWnd, 1);
		break;

	case WM_TIMER:
		InvalidateRect(hWnd, NULL, TRUE);
		break;

	case WM_SETFONT:
		if (wP) {
			SetWindowWord(hWnd, CLOCK_FONT, wP);
			InvalidateRect(hWnd, NULL, TRUE);
		}
		break;

	case CCM_QDEFAULTSIZE:
		hDC = GetDC(hWnd);
		if (hFont = GetWindowWord(hWnd, CLOCK_FONT))
			SelectObject(hDC, hFont);
		cr.left = cr.top = 0;
		cr.right = cr.bottom = 100;
		height = DrawText(hDC, "99:99:99", -1, &cr, DT_SINGLELINE | DT_CALCRECT);
		ReleaseDC(hWnd, hDC);
		return (MAKELONG(cr.right - cr.left + 2, height + 2));

	case CCM_GETFLAGS:
		return (CCF_INITGRAY | CCF_NOENABLES);

	case CCM_FORMSIZED:
	case CCM_RESETCONTENT:
	case CCM_GETNUM:
	case CCM_SETNUM:
	case CCM_GETSTRCOUNT:
	case CCM_SETSTR:
		break;

	case WM_ERASEBKGND:
		/* let WM_PAINT do it */
		return (1L);

	case WM_PAINT:
		InvalidateRect(hWnd, NULL, TRUE);
		BeginPaint(hWnd, &ps);
		hBackBr = (HBRUSH)SendMessage(GetParent(hWnd), WM_CTLCOLOR,
								ps.hdc, MAKELONG(hWnd, CTLCOLOR_STATIC));
		FillRect(ps.hdc, &ps.rcPaint, hBackBr);

		GetTime(&time);
		wsprintf(buf, "%02d:%02d:%02d", time.hr, time.min, time.sec);
		GetClientRect(hWnd, &cr);
		if (hFont = GetWindowWord(hWnd, CLOCK_FONT))
			SelectObject(ps.hdc, hFont);

		SetBkMode(ps.hdc, TRANSPARENT);
		DrawText(ps.hdc, buf, -1, &cr, DT_SINGLELINE | DT_CENTER | DT_VCENTER);
		EndPaint(hWnd, &ps);
		break;

	default:
		return (DefWindowProc(hWnd, msg, wP, lP));
	}

	return (0L);
}

/***********************************
 *  Countdown Timer Custom Control 
 ***********************************/

void FAR pascal
FormatSecs(HWND hWnd, LPSTR buf)
{
	WORD		wOn, wFmt, wSecs, w1, w2, w3;
	PSTR		pfmt;
	int			len, i;

	wOn = GetWindowWord(hWnd, TIMER_ON);
	wFmt = GetWindowWord(hWnd, TIMER_FORMAT);
	wSecs = GetWindowWord(hWnd, TIMER_DOWNCT);

	switch (wFmt) {

	case 2:
		w1 = wSecs / 60;
		w2 = wSecs % 60;
		pfmt = wOn ? (w1 < 100 ? "%02d:%02d" : "**:**") : "--:--";
		break;

	case 3:
		w1 = wSecs / 3600;
		wSecs = wSecs % 3600;
		w2 = wSecs / 60;
		w3 = wSecs % 60;
		pfmt =  wOn ? "%02d:%02d:%02d" : "--:--:--";
		break;

	default:
		w1 = wSecs;
		pfmt = wOn ? (w1 < 10000 ? "%d" : "****") : "-";
		break;
	}

	len = wsprintf(buf, pfmt, w1, w2, w3);

	if ((wOn & 2) != 0)
		for (i=0; i<len; i++)
			buf[i] = ' ';
}

LONG FAR PASCAL TimerSrv (hWnd, msg, wP, lP)
HWND		hWnd;
unsigned	msg;
WORD		wP;
LONG		lP;
{
	PAINTSTRUCT	ps;
	RECT		cr;
	HBRUSH		hBackBr;
	HFONT		hFont;
	HDC			hDC;
	LPLONG		lpLong;
	PSTR		pSampText;
	LONG		lTick;
	WORD		wOn;
	int			height, wCount;
	char		buf[10];

	switch (msg) {

	case WM_DESTROY:
		if (GetWindowWord(hWnd, TIMER_ON))
			KillTimer(hWnd, 1);
		break;

	case WM_TIMER:
		if (wOn = GetWindowWord(hWnd, TIMER_ON)) {
			InvalidateRect(hWnd, NULL, TRUE);
			if (wCount = GetWindowWord(hWnd, TIMER_DOWNCT)) {
				lTick = GetWindowLong(hWnd, TIMER_ENDTIC);
				lTick = (lTick - GetTickCount() + 500) / 1000;
				if (HIWORD(lTick))
					wCount = 0;
				else
					wCount = LOWORD(lTick);
				SetWindowWord(hWnd, TIMER_DOWNCT, wCount);
			} else {
				SetWindowWord(hWnd, TIMER_ON, wOn ^ 2);
			}
			if (wCount == 0)
				NotifyParent(hWnd);
		}
		break;

	case WM_SETFONT:
		if (wP) {
			SetWindowWord(hWnd, TIMER_FONT, wP);
			InvalidateRect(hWnd, NULL, TRUE);
		}
		break;

	case CCM_SETNUM:
		lpLong = (LPLONG)lP;
		lTick = lpLong[0];
		if (lTick < -1 || lTick > 65535) 
			return (0);	/* nSecs out of range */

		/* NOTE: allow 1st modifier to be -1 for no change */

		if (lTick >= 0) {
			SetWindowWord(hWnd, TIMER_DOWNCT, LOWORD(lTick));
			InvalidateRect(hWnd, NULL, TRUE);
			KillTimer(hWnd, 1);					/* re-synchronize */
			if (lTick == 0)
				SetWindowWord(hWnd, TIMER_ON, 0);
			else {
				SetWindowWord(hWnd, TIMER_ON, 1);
				if (!SetTimer(hWnd, 1, 1000, NULL))
					return(0);
				SetWindowLong(hWnd, TIMER_ENDTIC, 
								lTick * 1000 + GetTickCount());
			}
		}
		if (wP > 1) {
			lTick = lpLong[1];
			if (lTick < 1 || lTick > 3) 
				return (-1);	/* Error: format out of range */
			SetWindowWord(hWnd, TIMER_FORMAT, LOWORD(lTick));
			InvalidateRect(hWnd, NULL, TRUE);
		}
		if (wP > 2) return (-2);	/* Error: at most 2 modifiers */
		return (1);					/* OK */

	case CCM_GETNUM:
		if (GetWindowWord(hWnd, TIMER_ON))
			return (GetWindowWord(hWnd, TIMER_DOWNCT));
		else
			return (-1L);

	case CCM_QDEFAULTSIZE:
		hDC = GetDC(hWnd);
		if (hFont = GetWindowWord(hWnd, TIMER_FONT))
			SelectObject(hDC, hFont);
		cr.left = cr.top = 0;
		cr.right = cr.bottom = 100;
		switch (GetWindowWord(hWnd, TIMER_FORMAT)) {
			case 2:		pSampText = "99:99";		break;
			case 3:		pSampText = "99:99:99";		break;
			default:	pSampText = "9999";			break;
		}
		height = DrawText(hDC, pSampText, -1, &cr, DT_SINGLELINE | DT_CALCRECT);
		ReleaseDC(hWnd, hDC);
		return (MAKELONG(cr.right - cr.left + 2, height + 2));

	case CCM_GETFLAGS:
		return (CCF_INITGRAY | CCF_NOENABLES);

	case WM_ERASEBKGND:
		/* let WM_PAINT do it */
		return (1L);

	case WM_PAINT:
		InvalidateRect(hWnd, NULL, TRUE);	/* always do whole clock */
		BeginPaint(hWnd, &ps);
		hBackBr = (HBRUSH)SendMessage(GetParent(hWnd), WM_CTLCOLOR,
								ps.hdc, MAKELONG(hWnd, CTLCOLOR_STATIC));
		FillRect(ps.hdc, &ps.rcPaint, hBackBr);

		FormatSecs(hWnd, buf);
		GetClientRect(hWnd, &cr);
		if (hFont = GetWindowWord(hWnd, TIMER_FONT))
			SelectObject(ps.hdc, hFont);

		SetBkMode(ps.hdc, TRANSPARENT);
		DrawText(ps.hdc, buf, -1, &cr, DT_SINGLELINE | DT_RIGHT | DT_VCENTER);
		EndPaint(hWnd, &ps);
		break;

	case CCM_FORMSIZED:
	case CCM_RESETCONTENT:
	case CCM_GETSTRCOUNT:
	case CCM_SETSTR:
		break;

	default:
		return (DefWindowProc(hWnd, msg, wP, lP));
	}

	return (0L);
}

/***********************************
 *    Scroll Bar Custom Control 
 ***********************************/

void FAR pascal RedoSbar(HWND hwT)
{
	HWND		hSBar;
	int			minPos, maxPos, curPos, minAct, maxAct, curAct;

	if (!(hSBar = GetWindowWord(hwT, SBAR_SBAR))) return;

	minPos = GetWindowWord(hwT, SBAR_MIN);
	maxPos = GetWindowWord(hwT, SBAR_MAX);
	curPos = GetWindowWord(hwT, SBAR_VAL);

	GetScrollRange(hSBar, SB_CTL, &minAct, &maxAct);
	curAct = GetScrollPos(hSBar, SB_CTL);

	if (minAct != minPos || maxAct != maxPos)
		SetScrollRange(hSBar, SB_CTL, minPos, maxPos, curPos == curAct);

	if (curPos != curAct)
		SetScrollPos(hSBar, SB_CTL, curPos, TRUE);
}

void SBarMayNotify(HWND hItemW)
{
	int			curPos;

	curPos = GetWindowWord(hItemW, SBAR_VAL);
	if (curPos != GetWindowWord(hItemW, SBAR_NTFVAL)) {
		SetWindowWord(hItemW, SBAR_NTFVAL, curPos);
		NotifyParent(hItemW);
	}
}

LONG FAR PASCAL SSFilter(hSBar, msg, wP, lP)
HWND		hSBar;
unsigned	msg;
WORD		wP;
LONG		lP;
{
	LONG		retVal;
	BOOL		bCaptured;
	HWND		hItemW;

	retVal = CallWindowProc(origSBSrv, hSBar, msg, wP, lP);

	bCaptured = GetCapture() == hSBar;
	hItemW = GetParent(hSBar);

	if (bCaptured != GetWindowWord(hItemW, SBAR_HADCAP)) {
		if (!bCaptured)
			SBarMayNotify(hItemW);
		SetWindowWord(hItemW, SBAR_HADCAP, bCaptured);
	}
	return (retVal);
}


LONG FAR PASCAL ScrollSrv(hWnd, msg, wP, lP)
HWND		hWnd;
unsigned	msg;
WORD		wP;
LONG		lP;
{
	HWND		hSBar, hParW;
	RECT		cr;
	DWORD		classWS;
	int			defWd, defHt;
	int			minPos, maxPos, curPos, delta;
	int			thisM, minPosM, curPosM;
	BOOL		upFlag, bb, bHorz, bAlign1, bAlign2;
	WORD		sbflags;
	LONG		lt;
	LPLONG		lpl;

	switch (msg) {

	case WM_CREATE:
		/*	make a horizontal scroll bar unless FormSetObject modifier
			causes override.
		*/
		SetWindowWord(hWnd, SBAR_MAX, 100);
		SetWindowWord(hWnd, SBAR_PAGESZ, -10);	/* default to 10 pct */
		break;

	case CCM_FORMSIZED:
		/*	Abbreviated version of CCM_QDEFAULTSIZE code */
		sbflags = GetWindowWord(hWnd, SBAR_FLAGS);
		bHorz = (sbflags & SBF_VERT) == 0;
		bAlign1 = (sbflags & SBF_ALIGN1) != 0;
		bAlign2 = (sbflags & SBF_ALIGN2) != 0;

		if (!(bAlign1 || bAlign2)) break;

		GetClientRect(GetParent(hWnd), &cr);
		InflateRect(&cr, 1, 1);		/* slip border underneath edge */
		if (bHorz) {
			defHt = GetSystemMetrics(SM_CYHSCROLL);
			defWd = cr.right - cr.left;
			if (bAlign2)
				defWd -= (GetSystemMetrics(SM_CXVSCROLL) - 1);
			cr.top = cr.bottom - defHt;
		} else {
			defWd = GetSystemMetrics(SM_CXVSCROLL);
			defHt = cr.bottom - cr.top;
			if (bAlign2)
				defHt -= (GetSystemMetrics(SM_CYHSCROLL) - 1);
			cr.left = cr.right - defWd;
		}
		MoveWindow(hWnd, cr.left, cr.top, defWd, defHt, TRUE);
		break;

	case CCM_QDEFAULTSIZE:
		SendMessage(hWnd, CCM_FORMSIZED, 0, 0L);
			/* adjust item's client rect in case aligning */

		sbflags = GetWindowWord(hWnd, SBAR_FLAGS);
		bHorz = (sbflags & SBF_VERT) == 0;

		GetClientRect(hWnd, &cr);
		hSBar = CreateWindow("SCROLLBAR", "",
			WS_CHILD | WS_VISIBLE | (bHorz ? SBS_HORZ : SBS_VERT),
			cr.left, cr.top, cr.right - cr.left, cr.bottom - cr.top,
			hWnd, 1, GetWindowWord(hWnd, GWW_HINSTANCE), 0L);
		if (!hSBar) return (-1L);

		if (!sbFiltSrv) {
			sbFiltSrv = MakeProcInstance((FARPROC)SSFilter, hLibInstance);
			origSBSrv = (FARPROC)GetWindowLong(hSBar, GWL_WNDPROC);
		}
		SetWindowLong(hSBar, GWL_WNDPROC, (LONG)sbFiltSrv);
	
		SetWindowWord(hWnd, SBAR_SBAR, hSBar);
		RedoSbar(hWnd);

		bAlign1 = (sbflags & SBF_ALIGN1) != 0;
		bAlign2 = (sbflags & SBF_ALIGN2) != 0;
		if (bAlign1 || bAlign2)
			return (-2L);

		if (bHorz) {
			defHt = GetSystemMetrics(SM_CYHSCROLL);
			defWd = 100 + 2 * GetSystemMetrics(SM_CXHSCROLL);
		} else {
			defWd = GetSystemMetrics(SM_CXVSCROLL);
			defHt = 100 + 2 * GetSystemMetrics(SM_CYVSCROLL);
		}
		return (MAKELONG(defWd, defHt));

	case WM_SIZE:
		if (hSBar = GetWindowWord(hWnd, SBAR_SBAR))
			MoveWindow(hSBar, 0, 0, LOWORD(lP), HIWORD(lP), TRUE);
		break;

	case WM_HSCROLL:
	case WM_VSCROLL:
		if (hSBar = GetWindowWord(hWnd, SBAR_SBAR)) {
			upFlag = TRUE;
			minPos = GetWindowWord(hWnd, SBAR_MIN);
			maxPos = GetWindowWord(hWnd, SBAR_MAX);
			switch (wP) {

			case SB_LINEDOWN:
				upFlag = FALSE;
			case SB_LINEUP:
				delta = 1;
				break;

			case SB_PAGEDOWN:
				upFlag = FALSE;
			case SB_PAGEUP:
				delta = GetWindowWord(hWnd, SBAR_PAGESZ);
				if (delta < 0) {
					/* delta is a percentage */
					lt = maxPos - minPos;
					delta = (int)((lt * -delta) / 100);
				}
				if (delta < 1) delta = 1;
				break;

			case SB_THUMBPOSITION:
				curPos = LOWORD(lP);
				delta = 0;
				break;

			default:
				return (0L);
			}

			if (delta) {
				if (upFlag) delta = -delta;
				curPos = GetWindowWord(hWnd, SBAR_VAL) + delta;
			}

			if (curPos > maxPos)
				curPos = maxPos;
			else if (curPos < minPos)
				curPos = minPos;

			if (curPos != GetWindowWord(hWnd, SBAR_VAL)) {
				SetWindowWord(hWnd, SBAR_VAL, curPos);
				SetScrollPos(hSBar, SB_CTL, curPos, TRUE);
				if (wP == SB_THUMBPOSITION)
					SBarMayNotify(hWnd);
			}
		}
		break;

	case WM_ENABLE:
		if (hSBar = GetWindowWord(hWnd, SBAR_SBAR))
			EnableWindow(hSBar, wP);
		break;

	case CCM_SETNUM:
		/*	return:
				>= 1:				AOK,
				-k, 0 <= k < wP:	failed at lpl[k]
		*/
		lpl = (LPLONG)lP;
		thisM = 0;
		lt = lpl[thisM];
		hSBar = GetWindowWord(hWnd, SBAR_SBAR);
			/* NULL if from FormSetObject */
		if (!hSBar && lt >= CCSTYLE) {
			SetWindowWord(hWnd, SBAR_FLAGS, LOWORD(lt));
			thisM++;
		}
		if (thisM >= wP) return (1);

		/* set current value */
		minPos = GetWindowWord(hWnd, SBAR_MIN);
		maxPos = GetWindowWord(hWnd, SBAR_MAX);

		curPosM = thisM++;
		lt = lpl[curPosM];
		if (lt < -32767 || lt > 32767) return (-curPosM);
		curPos = LOWORD(lt);

		if (thisM < wP) {
			minPosM = thisM;
			lt = lpl[thisM];
			if (lt < -32767 || lt > 32767) return (-minPosM);
			minPos = LOWORD(lt);
			thisM++;
			if (thisM < wP) {
				lt = lpl[thisM];
				if (lt < -32767 || lt > 32767) return (-thisM);
				maxPos = LOWORD(lt);
				thisM++;
				if (thisM < wP) {
					lt = lpl[thisM];
					if (lt < -32767 || lt > 32767) return (-thisM);
					SetWindowWord(hWnd, SBAR_PAGESZ, LOWORD(lt));
					thisM++;
				}
			}
		}
		if (curPos < minPos || curPos > maxPos) return (-curPosM);
		if ((LONG)maxPos - minPos > 32767) return (-minPosM);

		if (thisM < wP) return (-thisM);

		SetWindowWord(hWnd, SBAR_MIN, minPos);
		SetWindowWord(hWnd, SBAR_MAX, maxPos);
		SetWindowWord(hWnd, SBAR_VAL, curPos);
		SetWindowWord(hWnd, SBAR_NTFVAL, curPos);

		RedoSbar(hWnd);

		return (1);				/* AOK */

	case CCM_GETNUM:
		return ((int)GetWindowWord(hWnd, SBAR_VAL));

	case CCM_GETSTRCOUNT:
	case CCM_GETSTRLEN:
	case CCM_GETSTR:
	case CCM_SETSTR:
	case CCM_RESETCONTENT:
		return (0L);

	default:
		return (DefWindowProc(hWnd, msg, wP, lP));
	}

	return (0L);
}


/***********************************
 *    Size Message Custom Control 
 ***********************************/

LONG FAR PASCAL SizeMsgSrv(hWnd, msg, wP, lP)
HWND		hWnd;
unsigned	msg;
WORD		wP;
LONG		lP;
{
	switch (msg) {

	case CCM_FORMSIZED:
		NotifyParent(hWnd);
		break;

	case CCM_QDEFAULTSIZE:
		MoveWindow(hWnd, -10, -10, 3, 3, 0);
		return (-2L);
				
	case CCM_GETFLAGS:
	case CCM_GETNUM:
	case CCM_SETNUM:
	case CCM_GETSTRCOUNT:
	case CCM_GETSTRLEN:
	case CCM_GETSTR:
	case CCM_SETSTR:
	case CCM_RESETCONTENT:
		return (0L);

	default:
		return (DefWindowProc(hWnd, msg, wP, lP));
	}
	return (0L);
}

/***********************************
 *    Lines Demo Custom Control 
 ***********************************/

LONG FAR PASCAL LinesSrv (hWnd, msg, wP, lP)
HWND		hWnd;
unsigned	msg;
WORD		wP;
LONG		lP;
{
	HDC			hDC;
	PAINTSTRUCT	ps;
	HBRUSH		hBackBr;
	HPEN		hOldPen;
	RECT		cr;
	int			x, y, cx, cy;

	switch (msg) {

	case WM_CREATE:
		SetWindowWord(hWnd, LINES_CX, 1);
		SetWindowWord(hWnd, LINES_CY, 1);
		SetWindowWord(hWnd, LINES_FILLFORM, 0);
		break;

	case CCM_QDEFAULTSIZE:
		if (GetWindowWord(hWnd, LINES_FILLFORM))
			return(-3L);
		return (MAKELONG(200, 100));

	case CCM_GETFLAGS:
	case CCM_GETNUM:
	case CCM_GETSTR:
	case CCM_GETSTRCOUNT:
	case CCM_GETSTRLEN:
		return (0);

	case CCM_SETNUM:
		SetWindowWord(hWnd, LINES_FILLFORM, wP);
		return(1L);

	case WM_ERASEBKGND:
		/* let WM_PAINT do it */
		return (1L);

	case WM_PAINT:
		BeginPaint(hWnd, &ps);
		hBackBr = (HBRUSH)SendMessage(GetParent(hWnd), WM_CTLCOLOR,
								ps.hdc, MAKELONG(hWnd, CTLCOLOR_STATIC));
		FillRect(ps.hdc, &ps.rcPaint, hBackBr);

		hOldPen = SelectObject(ps.hdc, 
			CreatePen(PS_SOLID, 1, GetTextColor(ps.hdc)));

		GetClientRect(hWnd, &cr);
		cx = GetWindowWord(hWnd, LINES_CX);
		cy = GetWindowWord(hWnd, LINES_CY);
		for (x = 0; x < cr.right; x+=3) {
			MoveTo(ps.hdc, cx, cy);
			LineTo(ps.hdc, x, 0);
		}
		for (y = 0; y < cr.bottom; y+=3) {
			MoveTo(ps.hdc, cx, cy);
			LineTo(ps.hdc, cr.right, y);
		}
		for (x = cr.right; x >= 0; x-=3) {
			MoveTo(ps.hdc, cx, cy);
			LineTo(ps.hdc, x, cr.bottom);
		}
		for (y = cr.bottom; y >= 0; y-=3) {
			MoveTo(ps.hdc, cx, cy);
			LineTo(ps.hdc, 0, y);
		}
		DeleteObject(SelectObject(ps.hdc, hOldPen));
		EndPaint(hWnd, &ps);
		break;

	case CCM_FORMSIZED:
		if (GetWindowWord(hWnd, LINES_FILLFORM)) {
			GetClientRect(GetParent(hWnd), &cr);
			MoveWindow(hWnd, cr.left, cr.top, cr.right, cr.bottom, TRUE);	
			SetWindowWord(hWnd, LINES_CX, (cr.right - cr.left)/2);
			SetWindowWord(hWnd, LINES_CY, (cr.bottom - cr.top)/2);
		}
		break;

	case WM_LBUTTONDOWN:
		SetWindowWord(hWnd, LINES_CX, LOWORD(lP));
		SetWindowWord(hWnd, LINES_CY, HIWORD(lP));
		InvalidateRect(hWnd, NULL, TRUE);

	default:
		return (DefWindowProc(hWnd, msg, wP, lP));
	}
	return (0L);
}

/*
 *  Standard DLL Functions
 */
 
int FAR PASCAL LibMain(hInstance, wDataSegment, wHeapSize, lpszCmdLine)
HANDLE      hInstance;
WORD        wDataSegment;
WORD        wHeapSize;
LPSTR       lpszCmdLine;
{
	WNDCLASS		wc;

	if (hLibInstance) return (TRUE);

	/* define class attributes */
	wc.style =			CS_HREDRAW | CS_VREDRAW | CS_GLOBALCLASS;
	wc.lpfnWndProc =	ClockSrv;
	wc.cbClsExtra =		0;
	wc.cbWndExtra =		CLOCK_EXTRA;
	wc.hInstance =		hInstance;
	wc.hIcon =			NULL;
	wc.hCursor =		LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground =	(HBRUSH)(COLOR_WINDOW + 1);
	wc.lpszMenuName =	NULL;
	wc.lpszClassName = 	CLOCK_CLASS;

	if (!RegisterClass(&wc)) return (FALSE);

	wc.lpfnWndProc =	TimerSrv;
	wc.cbWndExtra =		TIMER_EXTRA;
	wc.lpszClassName =	TIMER_CLASS;

	if (!RegisterClass(&wc)) return (FALSE);

	wc.lpfnWndProc =	ScrollSrv;
	wc.cbWndExtra =		SBAR_EXTRA;
	wc.lpszClassName =	SBAR_CLASS;

	if (!RegisterClass(&wc)) return (FALSE);

	wc.lpfnWndProc =	SizeMsgSrv;
	wc.cbWndExtra =		SIZEMSG_EXTRA;
	wc.lpszClassName = 	SIZEMSG_CLASS;

	if (!RegisterClass(&wc)) return (FALSE);

	wc.lpfnWndProc =	LinesSrv;
	wc.cbWndExtra =		LINES_EXTRA;
	wc.lpszClassName = 	LINES_CLASS;

	if (!RegisterClass(&wc)) return (FALSE);

	hLibInstance = hInstance;

	return (TRUE);
}

VOID FAR pascal WEP(bSystemExit)
int  bSystemExit;
{
	if (sbFiltSrv)
		FreeProcInstance(sbFiltSrv);
	return;
}
