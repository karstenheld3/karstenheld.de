README for WEBCNKIT.EXE

The Excel 97 Web Connectivity Kit was created for Internet or Intranet administrators, authors, and Excel users, and provides detailed information about using Excel 97 with the Internet or Intranet. Topics covered include Hyperlinks; Web Queries, which allow you to pull data from a Web server directly into Excel; and HTML extensions, which enhance HTML tables when brought into Excel. The Excel 97 Web Connectivity Kit consists of the document WebCnKit.doc and associated sample files. Open WebCnKit.doc in Word 97 to view or print it, then follow the instructions in WebCnKit.doc to use the various sample files. To learn about all of the sample files included in the Web Connectivity Kit, read the appendix which is part of WebCnKit.doc.

Important: You must have Excel 97 and Word 97 installed on your computer to use the Excel 97 Web Connectivity Kit.

The Kit is distributed as WEBCNKIT.EXE, a self-extracting compressed file. Copy it to a folder of your choice and double-click on the icon to expand the files.

This Excel 97 Web Connectivity Kit is included with the Office 97 Resource Kit from MS Press, and on several websites such as http://www.microsoft.com/excel/webquery.